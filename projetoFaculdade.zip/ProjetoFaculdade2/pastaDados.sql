create database faculdade;
use faculdade;
create table professor( 
id int primary key auto_increment,
nome varchar (100) not null,
);