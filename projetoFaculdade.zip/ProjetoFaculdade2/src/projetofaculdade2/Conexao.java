package projetofaculdade2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author adaltoss
 */
public class Conexao {
    
    //private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    
    private static final String URL = "jdbc:mysql://localhost:3306/projetoFaculdade"; // ?zeroDateTimeBehavior=convertToNull";
    private static final String USER = "root";
    private static final String SENHA = "12345";
    
    
    /* para quem instalou o XAMPP
    
    private static final String SENHA = "12345";
     */
    
    // para quem não instalou o XAMPP ou está nos PCs da FADERGS
    
    
    public static void executar(String query){
        try { 
            Class.forName( DRIVER );
            try (Connection conn = DriverManager.getConnection(URL,USER,SENHA)) {
                Statement st = conn.createStatement();
                st.execute( query );
                
            }
            
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("nao conectou");
            JOptionPane.showMessageDialog(null, e.toString());
        }
    }
    
    public static ResultSet consultar(String query){
        try {
            Class.forName( DRIVER );
            Connection conn = DriverManager.getConnection(URL,USER,SENHA);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery( query );
        //    conn.close();
            return rs;
        } catch (Exception e) {
            System.out.println("nao conectou");
            JOptionPane.showMessageDialog(null, e.toString());
            return null;
        }
    }   

    
    
}
